import React from 'react';
import { Route, Routes, BrowserRouter } from 'react-router-dom';
import Main from './Main';
import Grid from '../components/Grid';
import { aStar } from './../lib/aStar';

function App() {
  const handleRunAlgorithm = (grid, start, goal) => {
    console.log("🟢 handleRunAlgorithm ejecutado con:", { grid, start, goal });
    return aStar(grid, start, goal);
  };

  return (
    <>
      <Grid onRunAlgorithm={handleRunAlgorithm} />
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Main />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
