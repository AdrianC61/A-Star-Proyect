
// import React from "react";
// import Grid from "../components/Grid";
// import { aStar } from "../lib/aStar";

const Main = () => {
  // const handleRunAlgorithm = (grid, start, goal) => {
  //   if (!start || !goal) return;
  //   const path = aStar(grid, start, goal);
  //   console.log("Ruta encontrada:", path);
  //   console.log("Inicio:", start, "Meta:", goal);
  //   // Aquí puedes actualizar el estado para mostrar la ruta en la UI
  // };

  // return (
  //   <div className="p-4">
  //     <div title="p2">holaaaa</div>
  //     <Grid onRunAlgorithm={handleRunAlgorithm} />
  //   </div>
  // );
};

export default Main;
